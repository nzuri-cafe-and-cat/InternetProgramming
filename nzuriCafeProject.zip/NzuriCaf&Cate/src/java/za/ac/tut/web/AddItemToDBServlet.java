package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.ItemFacadeLocal;
import za.ac.tut.entities.Item;


public class AddItemToDBServlet extends HttpServlet {


    @EJB ItemFacadeLocal ifl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String image = request.getParameter("image");
        String name = request.getParameter("name");
        String description = request.getParameter("description");
        double price = Double.parseDouble(request.getParameter("price"));
        Long itemId = Long.parseLong(request.getParameter("itemId"));
        
        Item item = new Item();
        item.setImage(image);
        item.setName(name);
        item.setDescription(description);
        item.setPrice(price);
        item.setId(itemId);
        
        ifl.create(item);
        
        RequestDispatcher disp = request.getRequestDispatcher("managermenu.jsp");
        disp.forward(request, response);
    }
}
