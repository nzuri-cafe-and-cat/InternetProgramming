package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.ejb.bl.ItemFacadeLocal;
import za.ac.tut.entities.Item;


public class AddItemToCartServlet extends HttpServlet {

    @EJB ItemFacadeLocal ifl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(true);
        
        Long item = Long.parseLong(request.getParameter("item"));
        System.out.println(item);
        
        Item i = ifl.find(item);
        System.out.println(i.getName());
        
        List<Item> cart = (List<Item>)session.getAttribute("cart");
        cart.add(i);
        
        List<String> orderedItems = (List<String>)session.getAttribute("orderedItems");
        orderedItems.add(i.getName());
        
        double totalCost = (double)session.getAttribute("totalCost");
        totalCost = totalCost + i.getPrice();
        session.setAttribute("totalCost", totalCost);
        session.setAttribute("cart", cart);
        session.setAttribute("orderedItems", orderedItems);
        
        System.out.println(totalCost);
        
        String message = "Item added to cart successfully!";
        response.sendRedirect("addtocart.jsp?message=" + message);
       
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        RequestDispatcher disp = request.getRequestDispatcher("cart.jsp");
        disp.forward(request, response);
    }
}
